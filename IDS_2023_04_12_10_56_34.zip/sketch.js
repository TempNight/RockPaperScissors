let playerTurn; 
let computerTurn; 
let result; 


function setup() {
  createCanvas(400, 400);
  textAlign(200,200);
  textSize(20);
  resetGame();
}



function draw() {
  background(255);
  
  
  //display the players turn
  fill(0);
  text("Player:" + playerTurn, width/10, height/6); 
  //display the computers turn
  text("Computer:" + computerTurn, width/10, height/4);
  
  //display the result
  fill(0);
  text(result, width/2, height*3/4);
  
  }  


//Determine players turn based on what the player chooses





//generate the computers turn randomly
//const = Creates and names a new constant
const choices = ["rock", "paper", "scissors"];

//floor() = Calculates the closest int value that is less than or equal to the value of the parameter
//Math.floor = Returns a random number from 0 (inclusive) up to but not including 1 (exclusive).
const randomIndex = Math.floor(Math.random() * choices.length);
computerTurn = choices[randomIndex];


//determine the result 
if(playerTurn == computerTurn){
  result ="Tie";
} else if(
  (playerTurn === "rock" && computerTurn === "scissors") ||
  (playerTurn === "paper" && computerTurn === "rock") ||
  (playerTurn === "scissors" && computerTurn === "paper"))
{
    result = "That's a win!";
  } else {
    result = "That's a loss! Try again.";
  }


//reset game after 1 minute 
setTimeout(resetGame, 10000);

function resetGame() {
  playerTurn = "";
  computerTurn = "";
  result = "";
}
  




